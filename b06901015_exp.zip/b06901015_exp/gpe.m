function ygpe=gpe(m,g,h) %Gravity potential energy
ygpe=m*g*h;
