function yspe=spe(k,x)   %Spring potential energy
yspe=0.5*k*(x^2);